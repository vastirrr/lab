#include <iostream>
#include "nrcomplex.h"
#include "test.h"
#include "repository.h"

using namespace std;
int main() {
    testAll();
    Repo repo;
    repo.run_menu();
    return 0;
}

