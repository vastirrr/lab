#include "nrcomplex.h"

int modul(const NrComplex nr_complex);
