#ifndef REPO_H
#define REPO_H
#include "nrcomplex.h"
using namespace std;

class Repo{
private:
    NrComplex nr_complex[10];
    int no_complex;
public:
    Repo();
    ~Repo();

    void addItem(NrComplex &s);
    NrComplex getItemFromPos(int pos);
    int get_size();
    NrComplex max_of_complex_module();
    void print_menu();
    void run_menu();
    void print_all();
    void option_1();
    void complex_in_first_cadran();
    int longest_seq_equal_nr_complex();
    //void printArraysss(int& lenght, NrComplex* max_sequence);
    //int longest_seq_equal_nr_complex(Repo& s, NrComplex* seq_arr, int& max_size);
};
#endif
