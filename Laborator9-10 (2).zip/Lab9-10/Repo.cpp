//
// Created by rusva on 5/2/2023.
//


#include "Repo.h"
#include <algorithm>
#include "Moneda.h"
void TonomatRepository:: addItem(Produs produs) {
    produse.push_back(produs);
}

vector<Produs> TonomatRepository::  getAll() {
    return produse;
}

void TonomatRepository::adaugaProdus(Produs produs) {
    produse.push_back(produs);
}

//void TonomatRepository::adaugaProdus(Produs produs) {
//    for (auto it = produse.begin(); it != produse.end(); ++it) {
//        if (it->cod == produs.cod) {
//            throw std::runtime_error("Produsul cu acest cod deja exista!");
//        }
//    }
//    produse.push_back(produs);
//}


void TonomatRepository::stergeProdus(int cod) {
    for (auto it = produse.begin(); it != produse.end(); ++it) {
        if (it->cod == cod) {
            produse.erase(it);
            break;
        }
    }
}

void TonomatRepository::actualizeazaProdus(int cod, string nume, double pret) {
    for (auto it = produse.begin(); it != produse.end(); ++it) {
        if (it->cod == cod) {
            it->nume = nume;
            it->pret = pret;
            break;
        }
    }
}

Produs TonomatRepository::gasesteProdus(int cod) {
    for (auto it = produse.begin(); it != produse.end(); ++it) {
        if (it->cod == cod) {
            return *it;
        }
    }
    return Produs(-1, "", -1);
}

vector<Moneda> TonomatRepository::getMonezi() const {
    return moneziDisponibile;
}

//void TonomatRepository::adaugaMoneda(const Moneda& moneda) {
//    auto it = find(moneziDisponibile.begin(), moneziDisponibile.end(), moneda);
//    if (it != moneziDisponibile.end()) {
//        // Moneda exista deja, actualizam cantitatea
//        it->setCantitate(it->getCantitate() + moneda.getCantitate());
//    } else {
//        // Moneda nu exista, adaugam o noua intrare
//        moneziDisponibile.push_back(moneda);
//    }
//}

void TonomatRepository::adaugaMoneda(const Moneda& m) {
    moneziDisponibile.push_back(m);
}

vector<Produs> TonomatRepository::filteazaProduseDupaNume(string nume) {
    vector<Produs> produseFiltrate;
    for (auto it = produse.begin(); it != produse.end(); ++it) {
        if (it->nume == nume) {
            produseFiltrate.push_back(*it);
        }
    }
    return produseFiltrate;
}
