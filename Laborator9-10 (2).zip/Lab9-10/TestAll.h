//
// Created by rusva on 5/2/2023.
//

#ifndef LAB9_10_TESTALL_H
#define LAB9_10_TESTALL_H


class TestAll {

};


#endif //LAB9_10_TESTALL_H
