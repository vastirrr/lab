//
// Created by rusva on 5/2/2023.
//

#ifndef LAB9_10_TEST_H
#define LAB9_10_TEST_H

void test();
void test_actualizeazaProdus();
void testStergeProdus();
void test_gasesteProdus();
void test_filtrareProduseDupaNume();

#endif //LAB9_10_TEST_H
