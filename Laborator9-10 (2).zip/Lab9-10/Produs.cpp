//
// Created by rusva on 5/2/2023.
//

#include "Produs.h"

Produs:: Produs(int cod, string nume, double pret) {
    this->cod = cod;
    this->nume = nume;
    this->pret = pret;
}