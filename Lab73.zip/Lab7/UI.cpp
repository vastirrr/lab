//
// Created by Gabriel on 4/19/2023.
//

#include "UI.h"
#include <iostream>
#include "Entity.h"
#include <cstring>
#include <vector>
#import <ctime>

using namespace std;

UI::UI() = default;

UI::~UI() = default;

UI::UI(Service &service) {
    this->service = service;
}

void UI::runMenu() {
    printMenu();
    inputReader(input);
    while(true){
        if(input.size() == 1) break;
        if(strcmp(input[0], "adauga") == 0){
            service.addHistory();
            adaugareTranzactie(false);///MEMORY LEAK
        }
        else if(strcmp(input[0], "insereaza") == 0){
            service.addHistory();
            adaugareTranzactie(true);
        }
        else if(strcmp(input[0], "eliminare") == 0 or strcmp(input[0], "inocuire") == 0){
            service.addHistory();
            modificareTranzactii();
        }
        else if(strcmp(input[0], "listeaza") == 0 and input.size() == 2)
            afisare();
        else if(strcmp(input[0], "listeaza") == 0)
            identificareTranzactii();
        else if(strcmp(input[0], "sum") == 0 or strcmp(input[0], "max") == 0)
            sumMaxTranzactii();
        else if(strcmp(input[0], "filtru") == 0)
            filter();
        else if(strcmp(input[0], "undo") == 0)
            undo();
        else if(::strcmp(input[0], "x") == 0)
            break;
        else
            cout << "Optiune gresita!";
        input.clear();
        printMenu();
        inputReader(input);
    }
    cout << "Iesire din aplicatie...";
}

void UI::printMenu() {
    cout << "   " << "adauga/insereaza - ziua/suma/tip/descriere" << endl;
    cout << "   " << "eliminare/inlocuire - Modificare tranzactii" << endl;
    cout << "   " << "listeaza - Identificare tranzactii" << endl;
    cout << "   " << "sum/max - Obtinere caracteristici tranzactii" << endl;
    cout << "   " << "filtru - Filtrare tranzactii" << endl;
    cout << "   " << "undo - Undo" << endl;
    cout << "   " << "listeaza - Afisare tranzactii" << endl;
    cout << "   " << "x - Iesire din aplicatie" << endl;
}

void UI::adaugareTranzactie(bool dayIntroduced) {
    int day, sum;
    char* type, *description;
    if(not dayIntroduced){
        time_t now = time(0);
        tm* ltm = localtime(&now);
        day = ltm->tm_mday;
        sum = strToInt(input[1]);
        type = new char[strlen(input[2]) + 1]; strcpy(type, input[2]);
        description = new char[strlen(input[3]) + 1]; strcpy(description, input[3]);

    }
    else{
        day = strToInt(input[1]);
        sum = strToInt(input[2]);
        type = new char[strlen(input[3]) + 1]; strcpy(type, input[3]);
        description = new char[strlen(input[4]) + 1]; strcpy(description, input[4]);
    }
    this->service.addTranzactie(day, sum, type, description);
    free(type); free(description);
}

void UI::afisare() {
    Tranzaction* first = service.getAll();
    int size = service.getSize();
    for (int i = 0; i < size; i++) {
        cout << *(first + i) << endl;
    }
}

int UI::strToInt(const char *str) {
    int i = 0;
    int result = 0;
    while(*(str + i) != '\0') {
        result = 10 * result + *(str + i) - '0';
        i++;
    }
    return result;
}

void UI::modificareTranzactii() {
    char* copy = new char[strlen(input[0]) + 1];
    strcpy(copy, *input.begin());
    if(strcmp(copy, "eliminare") == 0) {
        if(input.size() >= 4) {
            char* first; first = new char[strlen(input[1]) + 1];
            strcpy(first, input[1]);
            char* second; second = new char[strlen(input[3]) + 1];
            strcpy(second, input[3]);
            service.eliminareTranzactii(first, second);
            free(first); free(second);
        }
        else if(input.size() == 3) {
            char* first; first = new char[strlen(input[1]) + 1];
            strcpy(first, input[1]);
            service.eliminareTranzactii(first);
            free(first);
        }
    }
    else{
        //TODO inlocuire tranz.
    }
    free(copy);
}

void UI::inputReader(vector<char *> &array) {
    char input[50];
    cin.getline(input, 50);
    char* arra;
    arra = strtok(input, " ");
    array.push_back(arra);
    while(arra != nullptr) {
        arra = strtok(nullptr, " ");
        array.push_back(arra);
    }
    free(arra);
}

void UI::identificareTranzactii() {
    char* first; first = new char[strlen(input[1]) + 1];
    char* second;
    strcpy(first, input[1]);
    if(input[2] != nullptr){
        second; second = new char[strlen(input[2]) + 1];
        strcpy(second, input[2]);
    }
    else
        second = nullptr;
    //TODO: De ce se sterge vectorul input
    vector <Tranzaction*> listaIdentificari; ///MEMORY LEAK
    service.identificareTranzactii(first, second,listaIdentificari);
    for(auto &i: listaIdentificari)
        cout << *i;
    free(first);
    if(second != nullptr) free(second);
}

void UI::sumMaxTranzactii() {
    ///MEMORY LEAK!!
    char* first; first = new char[strlen(input[1]) + 1];
    strcpy(first, input[1]);
    char token[] = "in";
    cout << service.sumTranzactii(token);
    free(first);
}

void UI::filter() {
    char token[] = "in"; ///MEMORY LEAK!!
    service.filter(token);
}

void UI::undo() {
    service.undo();
}


