//
// Created by Gabriel on 4/11/2023.
//

#ifndef LAB7_TEST_H
#define LAB7_TEST_H


class Test {
private:
    void test_entity();
    void test_repo();
    void test_service();
public:
    void test_all();
};


#endif //LAB7_TEST_H
