//
// Created by Gabriel on 4/11/2023.
//

#include "Test.h"
#include "Entity.h"
#include "Repo.h"
#include "Service.h"
#include <cassert>
#include <iostream>
#include <cstring>

void Test::test_all() {
    test_entity();
    test_repo();
    test_service();
}

void Test::test_entity() {
    //Test Constructors & Getters
    Tranzaction tranzaction1;
    assert(tranzaction1.get_day() == 0);
    assert(tranzaction1.get_sum() == 0);
    assert(tranzaction1.get_description() == nullptr);
    assert(tranzaction1.get_type() == nullptr);

    char type[] = "in";
    char description[] = "Pizza";
    Tranzaction tranzaction2(2, 50, &type[0], &description[0]);
    assert(tranzaction2.get_day() == 2);
    assert(tranzaction2.get_sum() == 50);
    assert(strcmp(tranzaction2.get_description(), description) == 0);
    assert(strcmp(tranzaction2.get_type(), type) == 0);

    Tranzaction tranzaction3(tranzaction2);
    assert(tranzaction3.get_day() == 2);
    assert(tranzaction3.get_sum() == 50);
    assert(strcmp(tranzaction3.get_description(), description) == 0);
    assert(strcmp(tranzaction3.get_type(), type) == 0);
}

void Test::test_repo() {
    Repo repo;
    Tranzaction tranzaction1;
    char type[] = "in";
    char description[] = "Pizza";
    Tranzaction tranzaction2(2, 50, &type[0], &description[0]);
    assert(repo.get_size() == 0);
    assert(repo.get_all() == nullptr);
    repo.add_elem(tranzaction1);
    assert(repo.get_size() == 1);
    assert(repo.get_all()->get_sum() == tranzaction1.get_sum());
    repo.add_elem(tranzaction2);
    assert((repo.get_all()+1)->get_sum() == tranzaction2.get_sum());
    repo.delete_(1);
    assert(repo.get_size() == 1);
    assert(repo.get_all()->get_sum() == tranzaction1.get_sum());
}

void Test::test_service() {
    Service service;
    assert(service.getAll() == nullptr);
    assert(service.getSize() == 0);
    char type[] = "in";
    char type2[] = "out";
    char description[] = "Pizza";
    service.addTranzactie(2, 50, type, description);
    assert(service.getAll()->get_sum() == 50);
    assert(service.getSize() == 1);
    service.eliminareTranzactii("in", nullptr);
    assert(service.getSize() == 0);
    service.addTranzactie(2, 100, type2, description);
    service.addTranzactie(4, 100, type, description);
    assert(service.getSize() == 2);
    service.eliminareTranzactii("out", nullptr);
    assert(service.getSize() == 1);
    service.addTranzactie(4, 100, type, description);
    service.eliminareTranzactii("4", "4");
    assert(service.getSize() == 0);
}

