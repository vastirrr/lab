//
// Created by Gabriel on 4/19/2023.
//

#ifndef LAB7_UI_H
#define LAB7_UI_H

#include "Service.h"

class UI {
private:
    Service service;
    vector <char*> input;
    void adaugareTranzactie(bool dayIntroduced);
    void printMenu();
    void afisare();
    static int strToInt(const char* str);
    void modificareTranzactii();
    void identificareTranzactii();
    static void inputReader(vector<char *> &array);
    void sumMaxTranzactii();
    void filter();
    void undo();
public:
    UI();
    UI(Service& service);
    ~UI();
    void runMenu();


};


#endif //LAB7_UI_H
