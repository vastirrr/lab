//
// Created by Gabriel on 4/11/2023.
//

#ifndef LAB7_REPO_H
#define LAB7_REPO_H

#include <vector>
#include <stack>
#include "Entity.h"

class Repo {
private:
    std::vector<Tranzaction> listaTranzactii;
    std::stack<vector<Tranzaction>> history;
public:
    Repo();
    ~Repo();
    void add_elem(Tranzaction& element);
    void delete_(int position);
    Tranzaction* getElem(int position);
    Tranzaction* get_all();
    int get_size();
    Repo& operator=(const Repo& rRight);
    void undo();
    void addHistory();
};


#endif //LAB7_REPO_H
