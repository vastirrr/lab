//
// Created by Gabriel on 4/19/2023.
//

#include <cstring>
#include "Service.h"
#include "Entity.h"
#include <type_traits>

Service::Service() = default;

Service::~Service() = default;

Service::Service(const Repo& repo) {
    this->repo = repo;
}

void Service::addTranzactie(int day, int sum, char *type, char *description) {
    Tranzaction tranzaction(day, sum, type, description);
    this->repo.add_elem(tranzaction);
}

Service &Service::operator=(const Service &rRight) {
    this->repo = rRight.repo;
    return *this;
}

Tranzaction* Service::getAll() {
    return repo.get_all();
}

int Service::getSize() {
    return repo.get_size();
}

void Service::eliminareTranzactii(const char *first, const char *second) {
    for (int i = 0; i < repo.get_size(); i++) {
        Tranzaction *tranzaction = repo.getElem(i);
        if (second != nullptr) {
            if (strToInt(first) <= tranzaction->get_day() and tranzaction->get_day() <= strToInt(second)) {
                repo.delete_(i);
                i--;
            }
        }
        else{
            if(strcmp(first, "in") == 0 or strcmp(first, "out") == 0){
                if(strcmp(first, tranzaction->get_type()) == 0){
                    repo.delete_(i);
                    i--;
                }
            }
            else{
                if(strToInt(first) == tranzaction->get_day()){
                    repo.delete_(i);
                    i--;
                }
            }
        }
    }
}

int Service::strToInt(const char *str) {
    int i = 0;
    int result = 0;
    while(*(str + i) != '\0') {
        result = 10 * result + *(str + i) - '0';
        i++;
    }
    return result;
}

void Service::identificareTranzactii(const char *first, const char *second, vector<Tranzaction *> &listaIdentificari) {
    if(second == nullptr) {
        for (int i = 0; i < repo.get_size(); i++) {
            Tranzaction* tranzaction = repo.getElem(i);
            if(strcmp(tranzaction->get_type(), first) == 0)
                listaIdentificari.push_back(tranzaction);
        }
    }
    else{
        if(::strcmp(first, "<") == 0){
            for (int i = 0; i < repo.get_size(); i++) {
                Tranzaction* tranzaction = repo.getElem(i);
                if(tranzaction->get_sum() < strToInt(second))
                    listaIdentificari.push_back(tranzaction);
            }
        }
        else if(::strcmp(first, "=") == 0){
            for (int i = 0; i < repo.get_size(); i++) {
                Tranzaction* tranzaction = repo.getElem(i);
                if(tranzaction->get_sum() == strToInt(second))
                    listaIdentificari.push_back(tranzaction);
            }
        }
        else if(::strcmp(first, "sol") == 0){
            //TODO
        }
    }
}

int Service::sumTranzactii(char *token) {
    int suma = 0;
    for (int i = 0; i < repo.get_size(); i++) {
        Tranzaction* tranzaction = repo.getElem(i);
        if(strcmp(token, tranzaction->get_type()) == 0){
            suma += tranzaction->get_sum();
        }
    }
    return suma;
}

void Service::filter(char *token) {
    for (int i = 0; i < repo.get_size(); i++) {
        Tranzaction* tranzaction = repo.getElem(i);
        if(strcmp(token, tranzaction->get_type()) == 0){
            repo.delete_(i);
        }
    }
}

void Service::undo() {
    return repo.undo();
}

void Service::addHistory() {
    repo.addHistory();
}
