//Problema 2

#include <iostream>
#include <cstring>
#include "Test.h"
#include "Repo.h"
#include "Service.h"
#include "UI.h"

int main() {
    Test test;
    //test.test_all();
    Repo repo;
    Service service(repo);
    UI ui(service);
    ui.runMenu();
    return 0;
}
