//
// Created by Gabriel on 4/11/2023.
//

#ifndef LAB7_ENTITY_H
#define LAB7_ENTITY_H

#include <iostream>

using namespace std;

class Tranzaction {
private:
    int day;
    int sum;
    char* type;
    char* description;
public:
    Tranzaction();
    Tranzaction(int day, int sum, char* type, char* description);
    ~Tranzaction();
    Tranzaction(const Tranzaction& initial);
    Tranzaction& operator=(const Tranzaction& initial);
    int get_day() const;
    int get_sum() const;
    char* get_type();
    char* get_description();
    friend ostream& operator<<(ostream& os, Tranzaction& tr);
};


#endif //LAB7_ENTITY_H
