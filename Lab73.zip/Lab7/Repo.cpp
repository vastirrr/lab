//
// Created by Gabriel on 4/11/2023.
//

#include "Repo.h"

Repo::Repo() = default;

Repo::~Repo() = default;

void Repo::add_elem(Tranzaction& element) {
//    bool not_empty = true;
//    if(get_size() == 0) not_empty = false;
//    if(not_empty)
//        history.push(this->listaTranzactii);
    listaTranzactii.push_back(element);
}

Tranzaction *Repo::get_all() {
    if(not listaTranzactii.empty())
        return &listaTranzactii[0];
    return nullptr;
}

int Repo::get_size() {
    return int(listaTranzactii.size());
}

Repo& Repo::operator=(const Repo &rRight) {
    for (int i = 0; i < rRight.listaTranzactii.size(); i++) {
        this->listaTranzactii[i] = rRight.listaTranzactii[i];
    }
    return *this;
}

void Repo::delete_(int position) {
    //history.push(listaTranzactii);
    if(0 <= position and position < get_size()){
        listaTranzactii.erase(listaTranzactii.begin() + position);
    }
}

Tranzaction *Repo::getElem(int position) {
    if(0 <= position and position < get_size())
        return &listaTranzactii[position];
    return nullptr;
}

void Repo::undo() {
    listaTranzactii = history.top();
    history.pop();
}

void Repo::addHistory() {
    if(get_size() > 0)
        history.push(listaTranzactii);
}
