//
// Created by Gabriel on 4/19/2023.
//

#ifndef LAB7_SERVICE_H
#define LAB7_SERVICE_H

#include "Repo.h"
#include <iostream>
#include "Entity.h"
#include <cstring>
#include <vector>

class Service {
private:
    Repo repo;
    static int strToInt(const char* str);
public:
    Service();
    Service(const Repo& repo);
    ~Service();
    void addTranzactie(int day, int sum, char *type, char *description);
    Service& operator=(const Service& rRight);
    Tranzaction* getAll();
    int getSize();
    void eliminareTranzactii(const char* first, const char* second= nullptr);
    void modificareTranzacti();
    void identificareTranzactii(const char *first, const char *second, vector<Tranzaction *> &listaIdentificari);
    int sumTranzactii(char* token);
    void filter(char* token);
    void undo();
    void addHistory();
};

#endif //LAB7_SERVICE_H
