//
// Created by Gabriel on 4/11/2023.
//

#include "Entity.h"
#include <cstring>


Tranzaction::Tranzaction(int day, int sum, char *type, char *description) {
    this->day = day;
    this->sum = sum;
    this->type = new char[strlen(type) + 1];
    strcpy(this->type, type);
    this->description = new char[strlen(description) + 1];
    strcpy(this->description, description);
}

Tranzaction::Tranzaction() {
    this->day = 0;
    this->sum = 0;
    this->type = nullptr;
    this->description = nullptr;
}

Tranzaction::~Tranzaction() {
    delete[] this->type; this->type = nullptr;
    delete[] this->description; this->description = nullptr;
}

Tranzaction::Tranzaction(const Tranzaction &initial) {
    this->day = initial.day;
    this->sum = initial.sum;
    if(initial.type == nullptr) this->type = nullptr;
    else{
        this->type = new char[strlen(initial.type) + 1];
        strcpy(this->type, initial.type);
    }
    if(initial.description == nullptr) this->description = nullptr;
    else{
        this->description = new char[strlen(initial.description) + 1];
        strcpy(this->description, initial.description);
    }
}

Tranzaction &Tranzaction::operator=(const Tranzaction &initial) {
    if(this != &initial){
        this->day = initial.day;
        this->sum = initial.sum;
        this->type = new char[strlen(initial.type) + 1];
        strcpy(this->type, initial.type);
        this->description = new char[strlen(initial.description) + 1];
        strcpy(this->description, initial.description);
    }
    return *this;
}

int Tranzaction::get_day() const {
    return day;
}

int Tranzaction::get_sum() const {
    return sum;
}

char *Tranzaction::get_type() {
    return type;
}

char *Tranzaction::get_description() {
    return description;
}

ostream &operator<<(ostream &os, Tranzaction &tr) {
    cout << "Ziua: " << tr.day << endl;
    cout << "Suma: " << tr.sum << endl;
    cout << "Tip: " << tr.type << endl;
    cout << "Descriere: " << tr.description << endl;
    return os;
}


