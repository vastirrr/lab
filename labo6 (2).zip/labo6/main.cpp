#include <iostream>
#include "NrComplex.h"
#include "Test.h"
#include "Repository.h"

using namespace std;
int main() {
    testAll();
    Repo repo;
    repo.run_menu();
    return 0;
}
