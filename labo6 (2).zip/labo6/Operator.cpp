#include "Operator.h"
#include "NrComplex.h"
#include <math.h>

int modul(NrComplex nr_complex) {
    int result;
    result = nr_complex.getReal() * nr_complex.getReal() + nr_complex.getImaginary() * nr_complex.getImaginary();

    return int(sqrt(result));
}
