//
// Created by rusva on 3/31/2023.
//
#ifndef NRCOMPLEX_H
#define NRCOMPLEX_H
#include <iostream>
#include <cmath>
#include <complex>
using namespace std;

class NrComplex {
private:
    int real;
    int imaginary;
public:
    NrComplex();
    NrComplex(int n, int a);
    NrComplex(const NrComplex& s);
    ~NrComplex();
    int getReal();
    int getImaginary();
    void setReal(int n);
    void setImaginary(int a);
    friend istream& operator>>(istream& is, NrComplex& complex_nr);
    friend ostream& operator<<(ostream& os, NrComplex& complex_nr);
    NrComplex operator+(const NrComplex& s);
    NrComplex operator-(const NrComplex& s);
    NrComplex operator*(const NrComplex& s);
    bool operator==(const NrComplex& s);
    bool operator>(const NrComplex& s);
    bool is_cadran();

};

#endif

// 2 atribute parte reala imaginara .. set get construct adunare, scadere, inmult, impartire 2 nr comple .. modulul unui nr compl