#include "NrComplex.h"

int modul(const NrComplex nr_complex);
