#ifndef REPO_H
#define REPO_H
#include "NrComplex.h"
#include <vector>
using namespace std;

class Repo{
private:
    vector<NrComplex> nr_complex;
//    NrComplex* nr_complex;
//    int no_complex, CAP;
public:
    Repo();
    ~Repo();

    void addItem(NrComplex &s);
    NrComplex getItemFromPos(int pos);
    void max_of_complex_module();
    void print_menu();
    void run_menu();
    void print_all();
    void option_1();
    void complex_in_first_cadran();
    int longest_seq_equal_nr_complex();
    void printAll(int start = 0, int length = 0);
    //void printArraysss(int& lenght, NrComplex* max_sequence);
    //int longest_seq_equal_nr_complex(Repo& s, NrComplex* seq_arr, int& max_size);
};
#endif
