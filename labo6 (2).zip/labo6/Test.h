#include "NrComplex.h"
#include "Operator.h"

void test_module();
void test_operations();
void test_maxModulus();
void test_longest_seq_equal_nr_complex();
void testAll();