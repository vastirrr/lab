#include "Repository.h"
#include "NrComplex.h"


Repo::Repo(){
//    CAP = 20;
//    nr_complex = new NrComplex[CAP];
//    this->no_complex = 0;
}

Repo::~Repo(){
//    delete[] nr_complex;
//    nr_complex == nullptr;
}

void Repo::addItem(NrComplex &s){
    nr_complex.push_back(s);
}

NrComplex Repo::getItemFromPos(int pos){
    return this->nr_complex[pos];
}

void Repo:: max_of_complex_module(){
    int size = nr_complex.size();
    NrComplex max_complex = this->nr_complex[0];

    for(int i = 1; i < size; i++){
        if(nr_complex[i] > max_complex){
            max_complex = nr_complex[i];
        }
    }
    cout <<  max_complex;
}

//void Repo::complex_in_first_cadran(){
//    int size = this->no_complex;
//    for(int i = 0; i < size; i++){
//        if(nr_complex[i].getImaginary() > 0 && nr_complex[i].getReal() > 0 ){
//             cout << nr_complex[i];
//        }
//    }
//}

void Repo::complex_in_first_cadran() {
    for (int i = 0; i < nr_complex.size(); i++) {
        if (nr_complex[i].is_cadran()) {
            cout << nr_complex[i];
        }
    }
}

int Repo::longest_seq_equal_nr_complex(){
    int max_length = 1;
    int poz = 0;
    int actaul_length = 1;

    for(int i = 0 ; i < nr_complex.size() - 1; i++){
        if(nr_complex[i] == nr_complex[i+1]){
            actaul_length++;
            if(actaul_length> max_length){
                max_length = actaul_length;
                poz = i - max_length +2;
                actaul_length =1;
            }
        }
    }
    printAll(poz, max_length);
}

void Repo::printAll(int start, int length) {
    if(length == 0){
        for(int i = start; i< nr_complex.size(); i++){
            cout << nr_complex[i];
        }
    }
    else{
        for(int i = start; i <start + length; i++){
            cout << nr_complex[i];
        }
    }
}

//int Repo::longest_seq_equal_nr_complex(){
//    int size = nr_complex.size();
//    int start = 0, end = 0, max_start = 0, max_end = 0;
//    int max_lenght = 0 , lenght = 0;
//
//    // aflam pozitia start max si end max ale seq_max
//    for (int i = 1; i < size; i++) {
//        if(nr_complex[i - 1] == nr_complex[i]){
//            lenght++;
//            if(lenght == 1){
//                start = i - 1;
//            }
//            end = i;
//        } else{
//            if(lenght > max_lenght){
//                max_lenght = lenght;
//                max_end = end;
//                max_start = start;
//            }
//            lenght = 0;
//            start = 0;
//            end = 0;
//        }
//    }
//
//    cout << max_start << " " << max_end << endl;
//    for(int i = max_start; i <= max_end; i++){
//        cout << nr_complex[i];
//    }
//    max_lenght += 1;
//    return max_lenght;
//}

//int Repo::longest_seq_equal_nr_complex(Repo& s, NrComplex* seq_arr, int& max_size){
//    int size = s.no_complex;
//    int is_first = 0;
//    int start = 0, end = 0, max_start = 0, max_end = 0;
//    // aflam pozitia start max si end max ale seq_max
//    for (int i = 1; i < size; i++) {
//        if((s.nr_complex[i - 1].getReal() == s.nr_complex[i].getReal())&&(s.nr_complex[i - 1].getImaginary() == s.nr_complex[i].getImaginary())){
//            if(is_first == 0){
//                is_first = 1;
//                start = i;
//            }
//            end++;
//        } else{
//            if((end - start + 1) > (max_end - max_start + 1)){
//                max_end = end;
//                max_start = start;
//            }
//            start = 0;
//            end = 0;
//        }
//    }
//
//    for(int i = max_start; i <= max_end; i++){
//        seq_arr[i] = s.nr_complex[i];
//    }
//
//    int max_lenght = max_end - max_start +1;
//    return max_lenght;
//}

//void Repo::printArraysss(int& lenght, NrComplex* max_sequence)
//{
//    for (int i = 0; i <= lenght; i++)
//    {
//        cout << max_sequence[i] << " ";
//    }
//}

void Repo::print_menu(){
    cout << "1. Adauga Entitate" << endl;
    cout << "2. Afisare Entitate" << endl;
    cout << "3. Afisati modulul maxim existent" << endl;
    cout << "4. Afisati numerele din primul cadran" << endl;
    cout << "5. Afisati cea mai lunga secv de numerele complexe egale" << endl;
    cout << "x. Iesire" << endl;
}

void Repo::print_all(){
    for(int i = 0; i< nr_complex.size(); i++){
        cout << nr_complex[i];
    }
}

void Repo:: option_1(){
    cout << "Introduceti partea reala: ";
    int real;
    int imaginar;

    cin >> real;

    cout << endl;

    cout << "Introduceti partea imaginara: ";
    cin >> imaginar;
    cout << endl;

    NrComplex complex = NrComplex(real, imaginar);
    addItem(complex);
}

void Repo::run_menu(){
    int option;
    NrComplex s;
    Repo arr;
    NrComplex* seq_arr = nullptr;
    int size = nr_complex.size();

    print_menu();
    while(scanf("%d", &option)){
        if (option == 1){
            option_1();
        }
        else if (option == 2){
            print_all();
        }
        else if(option == 3) {
            max_of_complex_module();
        } else if (option == 4){
            complex_in_first_cadran();
        } else if (option == 5){
             int rez = longest_seq_equal_nr_complex();

//            int rez = longest_seq_equal_nr_complex(arr, seq_arr, size);
//
//            cout << rez << endl;
//            printArraysss(rez, seq_arr);
        }

        print_menu();
    }
}
