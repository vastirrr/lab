//
// Created by rusva on 3/31/2023.
//

#include "NrComplex.h"
#include "Operator.h"
#include <iostream>

using namespace std;

// Constructor
NrComplex::NrComplex() {
    this->real = NULL;
    this->imaginary = 0;
}

// Constructor with parameters
NrComplex::NrComplex(int n, int a) {
    this->real = n;
    this->imaginary = a;
}

// Copy constructor
NrComplex::NrComplex(const NrComplex& s) {
    this->real = s.real;
    this->imaginary = s.imaginary;
}

// Desonstructor
NrComplex::~NrComplex() {
    this->real = NULL;
}

// getter
int NrComplex::getReal() {
    return this->real;
}

// getter
int NrComplex::getImaginary() {
    return this->imaginary;
}
// setter
void NrComplex::setReal(int n) {
    this->real = n;
}

// setter
void NrComplex::setImaginary(int a) {
    this->imaginary = a;
}

istream& operator>>(istream& is, NrComplex& complex_nr) {
    cout << "Introduceti partea reala: ";
    is >> complex_nr.real;
    cout << "Introduceti partea imaginara: ";
    is >> complex_nr.imaginary;
}

ostream& operator<<(ostream& os, NrComplex& complex_nr) {
    if(complex_nr.imaginary == 0)
    {
        cout << complex_nr.real << endl;
    }
    else{
        if(complex_nr.imaginary < 0)
        {
            cout << complex_nr.real << complex_nr.imaginary << "i" << endl;
        }
        else cout << complex_nr.real << "+" << complex_nr.imaginary << "i" << endl;
    }

    return os;
}

NrComplex NrComplex::operator+(const NrComplex& s) {
    return { this->real + s.real, this->imaginary + s.imaginary };
}

NrComplex NrComplex::operator-(const NrComplex& s) {
    return { this->real - s.real, this->imaginary - s.imaginary };
}

NrComplex NrComplex::operator*(const NrComplex& s) {
    return { this->real * s.real, this->imaginary * s.imaginary };
}

bool NrComplex::operator==(const NrComplex& s) {
    return this->real == s.real && this->imaginary == s.imaginary;
}

bool NrComplex::operator>(const NrComplex& s) {
    return modul(*this) > modul(s);
}

bool NrComplex::is_cadran() {
    return (imaginary >= 0 and real >= 0);
}
