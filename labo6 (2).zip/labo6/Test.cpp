#include "NrComplex.h"
#include "Operator.h"
#include "Test.h"
#include "Repository.h"
#include <cassert>
#include <iostream>

using namespace std;

void test_maxModulus() {
    NrComplex c1(3, 4);
    NrComplex c2(1, 2);

    NrComplex arr[] = { c1, c2};
    Repo r;
    NrComplex result;

    for(int i = 0; i < 2; i++){
        r.addItem(arr[i]);
    }
    assert(result == c2);
}

void test_cadran(){
    NrComplex c1(3, 4);
    NrComplex c2(1, 2);
    NrComplex c3(-1, 2);
    NrComplex arr[] = { c1, c2, c3};
    Repo r;
    NrComplex arr1[] = {};

    r.addItem(c1);
    r.addItem(c2);
    r.addItem(c3);

    assert(c1.is_cadran() == true);
    assert(c3.is_cadran() == false);
}

void test_module() {
    NrComplex no = NrComplex(4, 3);
    assert(modul(no)==5);

    NrComplex no2 = NrComplex(6, 8);
    assert(modul(no2)==10);
}

void test_operations() {
    NrComplex c1(3,4);
    NrComplex c2(7,6);
    NrComplex res;

    res=c2+c1;      ///testare adunare
    assert(res.getImaginary()==10);
    assert(res.getReal()==10);

    res=c1-c2;      ///testare scadere
    assert(res.getImaginary()==-2);
    assert(res.getReal()==-4);

    res=c1*c2;      /// testare inmultire
}
void test_longest_seq_equal_nr_complex() {
    Repo myRepo;
    NrComplex c1(1, 2);
    NrComplex c2(1, 3);
    NrComplex c3(1, 3);
    NrComplex c4(1, 3);
    NrComplex c5(4, 5);
    myRepo.addItem(c1);
    myRepo.addItem(c2);
    myRepo.addItem(c3);
    myRepo.addItem(c4);
    myRepo.addItem(c5);

    int expected_length = 3;
    int actual_length = myRepo.longest_seq_equal_nr_complex();
    assert(expected_length == actual_length);
}

void testAll(){
    test_operations();
    test_module();
    test_cadran();
    test_longest_seq_equal_nr_complex();
}